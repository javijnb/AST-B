public interface InterfazCalculadora {
	int sumar (int s1, int s2);
	int restar (int min, int sus);
	int multiplicar (int m1, int m2);
	float dividir (int num, int den);

}